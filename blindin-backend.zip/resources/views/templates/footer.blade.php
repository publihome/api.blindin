@include('public.addBottom')
@include('public.modalNew')

</div>
<script src="{{url('/js/app.js')}}"></script>
<script src="{{url('/js/modalNew.js')}}"></script>
<script src="{{url('/js/navbar.js')}}"></script>


</body>
</html>