@include('public.addBottom')
</div>
<script src="{{url('/js/app.js')}}"></script>
<script src="{{url('/js/navbar.js')}}"></script>


</body>
</html>