@include('templates.header')
@include('templates.navbar')

<div class="row" id="content">

    
</div>

@include('templates.footer')