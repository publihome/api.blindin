@include('templates.header')
@include('templates.navbar')

<div class="grid" id="content">

</div>


@include('templates.footer')