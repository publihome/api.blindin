@include('templates.header')
@include('templates.navbarAdmin')
<h1>hola</h1>


{{-- @include('templates.footer') --}}