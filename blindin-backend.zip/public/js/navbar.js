
const $oaxacabtn = document.getElementById('oaxaca')
const $mexicobtn = document.getElementById('nacional')
let region;


$('#btn-menu').click(function(e){
    $('.drop-menu').toggle('slow')
  })


function setRegion(reg){
    document.getElementById(reg).classList.add('btn-active-region')
    if(reg != region ){
        news = ""
    }
    region = reg   
    getData()
}

$oaxacabtn.addEventListener('click', () =>{
    $oaxacabtn.classList.add('btn-active-region')
    $mexicobtn.classList.remove('btn-active-region')
    setRegion('oaxaca')   
})

$mexicobtn.addEventListener('click', () => {
    $mexicobtn.classList.add('btn-active-region')
    $oaxacabtn.classList.remove('btn-active-region')
    setRegion('nacional')
})

setRegion('oaxaca')






