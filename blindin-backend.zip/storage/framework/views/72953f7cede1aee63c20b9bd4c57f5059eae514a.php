    <?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('templates.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(Session::get('mensaje')); ?>

    </div>
        <?php endif; ?>
        <div class="d-flex mb-2">
            <button class="btn btn-success ml-auto" data-bs-toggle="modal" data-bs-target="#modelAdd">Agregar</button>
        </div>

        <?php if(count($errors)> 0): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <P class="text-center">No rellenaste todos los campos!</P>
            </div>
        <?php endif; ?>
        

        <div class="list-group col-md-8 mx-auto">
            <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anuncio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item list-group-item-action d-flex flex-row justify-content-start" >
                    <div class="img">
                        <img src="<?php echo e(asset('storage').'/'.$anuncio->image); ?>" class="img-fluid mr-4 rounded" width="300" />
                    </div>
                    <div class="info mx-auto ">
                        <p class=".fs-2">Nombre de la publicidad: <span><?php echo e($anuncio->nombreMarca); ?></span></p>
                        <p class=".fs-2">Link: <span><?php echo e($anuncio->url); ?></span></p>
                        <p class=".fs-2">Posición: <span><?php echo e($anuncio->position == "top" ? "Arriba" : "Abajo"); ?></span></p>
                        <p class=".fs-2">Clicks: <span><?php echo e($anuncio->clicks); ?></span> </p>
                        <div class="d-flex ">
                        <a href="<?php echo e(url('admin/editPublicidad/'. $anuncio->id)); ?>" class="btn btn-warning mr-2">Editar</a>  
                            <form action="<?php echo e(url('/admin/deletePublicidad/'. $anuncio->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                                <input type="submit" class="btn btn-danger" value="Eliminar" onclick="return confirm('¿Quieres borrar?')">
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
        <?php if($anuncios->isEmpty()): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <h2 class="text-center">Aun no tienes anuncios, agrega uno</h2>
        </div>
        <?php endif; ?>


     <!-- Modal Agregar-->
     <div class="modal fade" id="modelAdd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Agreagar anuncio</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(url('/admin/addPublicidad')); ?>" method="post" enctype ="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('forms.FormAddPublicidad',['mode' => 'add'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-success">Añadir</button>
            </form>
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
        </div>
    </div>


<?php echo $__env->make('templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\WebDesigner\Desktop\blindin-backend\resources\views/publicidad/index.blade.php ENDPATH**/ ?>