
    </div>

</body>
</html><?php /**PATH C:\Users\WebDesigner\Desktop\blindin-backend\resources\views/templates/footer.blade.php ENDPATH**/ ?>