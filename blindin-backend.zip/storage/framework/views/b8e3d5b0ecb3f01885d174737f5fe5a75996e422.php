<div class="form-group">
    <label for="nombre">Nombre de la marca</label>
    <input type="text" class="form-control <?php $__errorArgs = ['nombreMarca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($data->nombreMarca) ?  $data->nombreMarca  : old('nombreMarca')); ?>" name="nombreMarca">
    <?php $__errorArgs = ['nombreMarca'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger">Compo obligatorio</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">
    <label for="image">Imagen</label>
    <?php if(isset($data->image)): ?>
    <div class="img-fluid my-2 row justify-content-center">
        <img src="<?php echo e(asset('storage') .'/'. $data->image); ?>" width=160 alt="<?php echo e($data->nombreMarca); ?>">
    </div>    
     <?php endif; ?>
    <input type="file" class="form-control" value="" name="image">
    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger">la imagen es obligatoria</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
    <label for="url">URL del sitio</label>
    <input type="text" class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($data->url) ? $data->url : old('url')); ?>" name="url">
    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger">Compo obligatorio</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<div class="form-group">
    <label for="position">Posición del anuncio</label>
    <select name="position" id="" class="form-control <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php if(isset($data->position)): ?>  
            <option value="<?php echo e($data->position); ?>" >
            <?php if($data->position == 'top'): ?> 
              Arriba 
              <?php else: ?>
               Abajo
               <?php endif; ?>
            </option>
            <?php if($data->position === "top"): ?>
            <option value="down">Abajo</option>
            <?php else: ?>
            <option value="top">Arriba</option>
            <?php endif; ?>
        <?php else: ?>
        <option value="">selecciona la posicion donde quieras que se vea el anuncio</option>
        <option value="top">Arriba</option>
        <option value="down">Abajo</option>
        <?php endif; ?>
    </select>
    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger">Compo obligatorio</small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    
</div>

<!-- <button class="btn btn-success btn-large">Añadir</button> --><?php /**PATH C:\Users\WebDesigner\Desktop\blindin-backend\resources\views/forms/FormAddPublicidad.blade.php ENDPATH**/ ?>